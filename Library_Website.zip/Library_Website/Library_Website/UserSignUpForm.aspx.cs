﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using UserInterfaces;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

public partial class UserSignUpForm : System.Web.UI.Page
{
    static string userEndPoint;
    IUser userObj;
    TcpChannel channel = new TcpChannel();

    static UserSignUpForm()
    {
        userEndPoint = ConfigurationManager.AppSettings["IUserEndPoint"];
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            channel = new TcpChannel();
            ChannelServices.RegisterChannel(channel, false);
            userObj = (IUser)Activator.GetObject(typeof(IUser), userEndPoint);
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {
            ChannelServices.UnregisterChannel(channel);
            channel = null;
        }
        string dataValues = string.Empty;
        dataValues += txtUserName.Text + "," + txtPassword.Text + "," + txtEmail.Text + ",";
        dataValues += txtSecuQues.Text + "," + txtSecuAns.Text;
        if (userObj.CreateUser(dataValues))
        {
            lblResponseMessage.ForeColor = System.Drawing.Color.Green;
            lblResponseMessage.Text = "<< User Created Successfully >>";
        }
        else
        {
            lblResponseMessage.ForeColor = System.Drawing.Color.Red;
            lblResponseMessage.Text = "<< User Creation Failed >>";
        }
    }
}
