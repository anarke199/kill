﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using UserInterfaces;

public partial class ChangePassword : System.Web.UI.Page
{
   
    IUser userObj;
    string userEndPoint;

    public ChangePassword()
    {
        userEndPoint = ConfigurationManager.AppSettings["IUserEndPoint"];
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (txtOldPassword.Text != "" || txtNewPassword.Text != "")
        {
            try
            {
                if (ChannelServices.RegisteredChannels.Length == 0)
                {
                    TcpChannel channel = new TcpChannel();
                    ChannelServices.RegisterChannel(channel, false);
                }
                userObj = (IUser)Activator.GetObject(typeof(IUser), userEndPoint);
                string changePassInfo = Session["username"].ToString() + ",";
                changePassInfo += txtOldPassword.Text + "," + txtNewPassword.Text;
                if (userObj.ChangePassword(changePassInfo))
                {
                    lblMessage.ForeColor = System.Drawing.Color.Green;
                    lblMessage.Text = "<< Password changed successfully! >>";
                    btnChange.Enabled = false;
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "<< Unable to change Password! >>";
                }

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        else
        {
            lblMessage.Text = "Enter both passwords";
        }
    }
}
