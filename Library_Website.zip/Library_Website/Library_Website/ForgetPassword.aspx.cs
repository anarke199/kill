﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using UserInterfaces;

public partial class ForgetPassword : System.Web.UI.Page
{
    IUser userObj;
    static string userEndPoint;
    string secQ, secA, pass;
    static ForgetPassword()
    {
        userEndPoint = ConfigurationManager.AppSettings["IUserEndPoint"];
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnGetQuestion_Click(object sender, EventArgs e)
    {
        try
        {
            if (ChannelServices.RegisteredChannels.Length == 0)
            {
                TcpChannel channel = new TcpChannel();
                ChannelServices.RegisterChannel(channel, false);
            }
            userObj = (IUser)Activator.GetObject(typeof(IUser), userEndPoint);
            string returnVal = userObj.GetSecurityInfo(txtUserName.Text);
            if (returnVal != string.Empty)
            {
                secQ = returnVal.Substring(0, returnVal.IndexOf(','));
                returnVal = returnVal.Substring(returnVal.IndexOf(',') + 1);
                secA = returnVal.Substring(0, returnVal.IndexOf(','));
                pass = returnVal.Substring(returnVal.IndexOf(',') + 1);
                if (secQ != "" || secA != "")
                {
                    Session.Add("SecQ", secQ);
                    Session.Add("SecA", secA);
                    Session.Add("Pass", pass);
                    lblSecurityQuestion.Text = secQ;
                    txtSecurityAnswer.Enabled = true;
                    btnSubmit.Enabled = true;
                }
                else
                {
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                    lblMessage.Text = "Sorry! Please contact your administrator";
                }
            }
            else
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "No such user exists!";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        secQ = Session["SecQ"].ToString();
        secA = Session["SecA"].ToString();
        pass = Session["Pass"].ToString();
        if (secQ != "" && secA == txtSecurityAnswer.Text)
        {
            lblPassword.Text = pass;
            lblMessage.Text = "";
        }
        else
        {
            lblMessage.ForeColor = System.Drawing.Color.Red;
            lblMessage.Text = "Sorry! wrong answer";
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        if (txtUserName.Text == "")
        {
            txtUserName.Text = " ";
        }
    }
}
