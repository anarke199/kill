﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using UserInterfaces;

public partial class Home : System.Web.UI.Page
{
    
    IUser userObj;
    static string userEndPoint;

    static Home()
    {
        userEndPoint = ConfigurationManager.AppSettings["IUserEndPoint"];
    }

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
            {
            if(ChannelServices.RegisteredChannels.Length==0)
            {
                TcpChannel channel = new TcpChannel();
                ChannelServices.RegisterChannel(channel, false);
            }
                userObj = (IUser)Activator.GetObject(typeof(IUser), userEndPoint);
                string dataValues = string.Empty;
                dataValues += txtUserName.Text.Trim() + "," + txtPassword.Text.Trim();
                if (userObj.Authenticate(dataValues))
                {
                    Session["username"] = txtUserName.Text;
                    Response.Redirect("SearchBooks.aspx", false);
                    //Server.Transfer("SearchBooks.aspx",true);
                }
                else
                {
                    lblMessage.Text = "Login Failed! Check Username and Password";
                }
            }

            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
    }
}
