﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using UserInterfaces;

public partial class ChangeUserProfile : System.Web.UI.Page
{
    TcpChannel channel;
    IUser userObj;
    string userEndPoint;


    public ChangeUserProfile()
    {
        userEndPoint = ConfigurationManager.AppSettings["IUserEndPoint"];
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ChangeButton_Click(object sender, EventArgs e)
    {
        if (userNameTextBox.Text != "" && emailTextBox.Text != "")
        {
            try
            {
                channel = new TcpChannel();
                ChannelServices.RegisterChannel(channel, false);
                userObj = (IUser)Activator.GetObject(typeof(IUser), userEndPoint);
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                ChannelServices.UnregisterChannel(channel);
                channel = null;
            }
        }
        else
        {
            lblMessage.Text = "Enter both passwords";
        }
    }
}
