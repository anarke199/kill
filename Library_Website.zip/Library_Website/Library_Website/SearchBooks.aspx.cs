﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
//using BookInterfaces;
using LibraryInterfaces;


public partial class SearchBooks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            DataSet dsBook = GetAllCriteriaForSearch();


            //ddlTitle.DataSource = dsBook.Tables["SearchCriteria1"];
            //ddlTitle.DataTextField = "book_publisher_name";
            //ddlTitle.DataBind();

            ddlCategory.DataSource = dsBook.Tables["SearchCriteria"];
            ddlCategory.DataTextField = "category_name";
            ddlCategory.DataValueField = "category_id";
            ddlCategory.DataBind();

            //ddlAuthor.DataSource = dsBook.Tables["SearchCriteria1"];
            //ddlAuthor.DataTextField = "book_publisher_name";
            //ddlAuthor.DataBind();

            ddlPublisher.DataSource = dsBook.Tables["SearchCriteria1"];
            ddlPublisher.DataTextField = "book_publisher_name";
            ddlPublisher.DataBind();
        }
    }


   
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        SearchBooksByCriteria();
    }

    private DataSet GetAllCriteriaForSearch()
    {
        DataSet dsCriteria = null;

        regChannels();
        
        try
        {
            IBook book;
            book = (IBook)Activator.GetObject(typeof(IBook), ConfigurationManager.AppSettings["IBookEndPoint"]);
            dsCriteria = book.GetAllCriteriaForBookSearch();
        }
        catch (Exception exc)
        {
            Response.Write(exc.Message);
        }
        return dsCriteria;
    }
    private void SearchBooksByCriteria()
    {
        string title = ddlTitle.SelectedValue;
        string categoryId = ddlCategory.SelectedValue;
        string author = ddlAuthor.SelectedValue;
        string publisherName = ddlPublisher.SelectedValue;
        
        
        string whereClause = " where b.book_category=c.category_id  and  b.book_id=d.book_id and (b.book_category=" + categoryId + " or b.book_publisher_name= '" + publisherName + "')";
        DataSet dsBooks = null;

        regChannels();
        

        try
        {
            IBook book;
            book = (IBook)Activator.GetObject(typeof(IBook), ConfigurationManager.AppSettings["IBookEndPoint"]);

            if (dsBooks == null)
            {
                dsBooks = book.GetBooks(whereClause);
            }
            else
            {
                Response.Write("cache is working");
            }
            BookDetailsGridView.AutoGenerateColumns = false;
            BookDetailsGridView.DataSource = dsBooks;

            BookDetailsGridView.DataBind();
            //BookDetailsGridView.Columns[3].Visible = false;
        }
        catch (Exception exc)
        {
            Response.Write(exc.Message);
        }

    }
    protected void btnReport_Click(object sender, EventArgs e)
    {

    }
    protected void BookDetailsGridView_SelectedIndexChanged(object sender, EventArgs e)
    {
        int selectedIndex = BookDetailsGridView.SelectedIndex;
        string bookId = BookDetailsGridView.Rows[selectedIndex].Cells[3].Text.ToString();

        Session["bookId"] = bookId;
        Server.Transfer("~/BookDetails.aspx");
    }

    private void regChannels()
    {
        if (ChannelServices.RegisteredChannels.Length == 0)
        {
            TcpChannel channel = new TcpChannel();
            ChannelServices.RegisterChannel(channel, false);
        }
    }

}
