﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblDate.Text = DateTime.Today.Date.ToShortDateString();
        lblDay.Text = DateTime.Now.DayOfWeek.ToString();
        lblUserName.Text = " " + Session["username"];        

        //if(Session.IsNewSession || Session["username"] =="")
        //{
        //    Session.Abandon();
        //    Response.Redirect("Login.aspx");
        //}
        //else
        //{
        //    Session.Timeout=20;
        //}
        
    }
    protected void btnLogOut_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }
}
