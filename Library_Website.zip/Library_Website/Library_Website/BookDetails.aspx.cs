﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Web.Caching;
using System.Data;
using System.Configuration;
//using BookInterfaces;
using LibraryInterfaces;

public partial class BookDetails : System.Web.UI.Page
{
    string selectedBookId = string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            regChannel();
            try
            {
                IBook book;
                book = (IBook)Activator.GetObject(typeof(IBook), ConfigurationManager.AppSettings["IBookEndPoint"]);

                string bookId = (string)Session["bookId"];
                DataSet dsBookDetail = book.GetBookDetail(bookId);
                // BookDetailGridView.AutoGenerateColumns = false;
                BookDetailGridView.DataSource = dsBookDetail.Tables["BookDetails"];
                BookDetailGridView.DataBind();

                BookTitleAns.Text = dsBookDetail.Tables["BookDetails"].Rows[0]["book_title"].ToString();
                BookAuthorAns.Text = dsBookDetail.Tables["BookDetails"].Rows[0]["book_author_name"].ToString();
                BookPublisherAns.Text = dsBookDetail.Tables["BookDetails"].Rows[0]["book_publisher_name"].ToString();
            }
            catch (Exception exc)
            {
                Response.Write(exc.Message);
            }
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //if button is not selected then ask user to select the book first then 

        if (!CheckBoxIssue.Checked)
        {
            // IssueBookButton.Enabled = true;
            this.RegisterClientScriptBlock("Warning", "<script> alert('Please Select the Issue check Box')</script>");
            // ValidationSummary1.ShowMessageBox("Please Select the Issue check Box");
            Response.Write("Please Select the Issue check Box");
        }
        else
        {
            string BookCopyId = (string)Session["PhysicalBookId"];
            int transId = GetTransactionId();
            if (transId > 0)
            {

            }
            else
            {
                Response.Write("Could Not Issue");
            }
        }
    }
    public int GetTransactionId()
    {
        return 1;
    }
    protected void BookDetailGridView_SelectedIndexChanged(object sender, EventArgs e)
    {
        int index = BookDetailGridView.SelectedIndex;
        string selectedBookId = BookDetailGridView.Rows[index].Cells[1].Text.ToString();
        Session["PhysicalBookId"] = selectedBookId;
    }
    protected void CheckBoxIssue_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBoxIssue.Checked)
        {
            btnSubmit.Enabled = true;
        }
    }
    private void regChannel()
    {
        if (ChannelServices.RegisteredChannels.Length == 0)
        {
            TcpChannel channel = new TcpChannel();
            ChannelServices.RegisterChannel(channel, false);
        }
    }
}
